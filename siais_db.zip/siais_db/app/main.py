from fastapi import FastAPI
from app.api.auth import router as auth_router

app = FastAPI(title="SIAIS Analytics")

app.include_router(auth_router, prefix="/auth")

from app.db.control_db import get_control_db
from sqlalchemy import text
from fastapi import Depends
from sqlalchemy.orm import Session

@app.get("/health/control-db")
def control_db_health(db: Session = Depends(get_control_db)):
    result = db.execute(text("SELECT 1")).scalar()
    return {"control_db": result}