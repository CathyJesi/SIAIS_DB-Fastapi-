from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.jwt import get_current_user
from app.db.control_db import get_control_db
from app.db.tenant_db import build_tenant_db_url, get_tenant_session
from app.models.control.tenant_databases import TenantDatabase

def get_tenant_db(
    token=Depends(get_current_user),
    control_db: Session = Depends(get_control_db),
):
    tenant_code = token.get("tenant_code")

    tenant_db = (
        control_db.query(TenantDatabase)
        .filter(TenantDatabase.db_name == f"siais_tenant_{tenant_code}")
        .first()
    )

    if not tenant_db:
        raise HTTPException(status_code=404, detail="Tenant DB not found")

    db = get_tenant_session(build_tenant_db_url(tenant_db))
    try:
        yield db
    finally:
        db.close()