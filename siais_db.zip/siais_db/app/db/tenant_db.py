from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from functools import lru_cache

def build_tenant_db_url(db):
    return (
        f"postgresql+psycopg2://{db.db_user}:"
        f"{db.db_password}@{db.db_host}:"
        f"{db.db_port}/{db.db_name}"
    )

@lru_cache(maxsize=100)
def get_engine(db_url: str):
    return create_engine(db_url, pool_pre_ping=True)

def get_tenant_session(db_url: str):
    engine = get_engine(db_url)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    return Session()