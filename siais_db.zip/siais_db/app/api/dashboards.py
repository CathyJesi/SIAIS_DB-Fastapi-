from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.dependencies.tenant import get_tenant_db
from app.models.tenant.dashboards import Dashboard

router = APIRouter()

@router.get("/dashboards")
def list_dashboards(db: Session = Depends(get_tenant_db)):
    return db.query(Dashboard).all()