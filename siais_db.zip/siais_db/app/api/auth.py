from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.control_db import get_control_db
from app.models.control.users import User
from app.models.control.tenant_databases import TenantDatabase
from app.core.security import verify_password
from app.core.jwt import create_access_token

router = APIRouter()

@router.post("/login")
def login(email: str, password: str, db: Session = Depends(get_control_db)):
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    tenant_db = db.query(TenantDatabase).filter(
        TenantDatabase.tenant_id == user.tenant_id
    ).first()

    token = create_access_token({
        "sub": str(user.id),
        "tenant_code": tenant_db.db_name.replace("siais_tenant_", "")
    })

    return {"access_token": token}