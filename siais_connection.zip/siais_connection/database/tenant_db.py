import psycopg2
from config import DB_CONFIG

def get_tenant_connection(db_name):
    return psycopg2.connect(
        database=db_name,
        **DB_CONFIG
    )