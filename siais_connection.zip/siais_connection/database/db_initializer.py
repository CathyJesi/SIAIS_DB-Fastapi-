from database.tenant_db import get_tenant_connection

def initialize_client_tables(db_name):
    conn = get_tenant_connection(db_name)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE data_purchase_orders (
            id SERIAL PRIMARY KEY,
            order_date DATE,
            amount NUMERIC
        );

        CREATE TABLE data_sales_order_items (
            id SERIAL PRIMARY KEY,
            product_name VARCHAR(255),
            quantity INT
        );
    """)

    conn.commit()
    cur.close()
    conn.close()