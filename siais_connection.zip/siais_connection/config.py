DB_CONFIG = {
    "host": "localhost",
    "user": "postgres",
    "password": "postgres",
    "port": 5432
}