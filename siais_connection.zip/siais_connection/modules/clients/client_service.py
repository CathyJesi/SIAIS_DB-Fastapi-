from database.master_db import get_master_connection
from database.db_initializer import initialize_client_tables

def create_client(client_name):
    db_name = f"siais_{client_name.lower().replace(' ', '_')}"

    conn = get_master_connection()
    conn.autocommit = True
    cur = conn.cursor()

    # Create new database
    cur.execute(f'CREATE DATABASE "{db_name}"')

    # Save in master table
    cur.execute(
        "INSERT INTO clients (client_name, database_name) VALUES (%s, %s)",
        (client_name, db_name)
    )

    cur.close()
    conn.close()

    # Create tables inside new DB
    initialize_client_tables(db_name)