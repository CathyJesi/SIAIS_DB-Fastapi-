from fastapi import FastAPI
from db import get_connection
import uvicorn

app = FastAPI()

@app.get("/")
def home():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT 'PostgreSQL Connected Successfully!'")
    msg = cur.fetchone()[0]
    cur.close()
    conn.close()
    return {"message": msg}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)