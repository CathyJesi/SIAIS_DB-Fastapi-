import psycopg2
from modules.clients.client_service import create_client
create_client("Amazon")

def create_client_database(client_name):
    db_name = f"siais_{client_name.lower()}"

    conn = psycopg2.connect(
        host="localhost",
        database="siais",   # connect to master DB
        user="postgres",
        password="postgres",
        port=5432
    )
    conn.autocommit = True
    cur = conn.cursor()

    # 1. Create new database
    cur.execute(f"CREATE DATABASE {db_name};")

    # 2. Insert record in master table
    cur.execute(
        "INSERT INTO clients (client_name, database_name) VALUES (%s, %s)",
        (client_name, db_name)
    )
    
    cur.close()
    conn.close()