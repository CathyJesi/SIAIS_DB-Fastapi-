import psycopg2

def get_connection():
    return psycopg2.connect(
        dbname="analytics_db",
        user="cathrene",
        password="password",
        host="/opt/homebrew/var/postgresql@16",
        port="5432"
    )